export const REGISTER_USER = 'REGISTER_USER';
export const LOGIN_USER = 'LOGIN';
export const AUTH_START = 'AUTH_START';
export const AUTH_SUCCESS = 'AUTH_SUCCESS';
export const AUTH_FAILED = 'AUTH_FAILED';
export const AUTH_LOGOUT = 'LOGOUT';

export const GETALL_TWEETS = 'GETALLTWEETS';
export const LIKE_TWEET = 'LIKE_TWEET';