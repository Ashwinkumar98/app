package com.tweetapp.exception;

public class TweetAppException extends Exception {

	private static final long serialVersionUID = 4913867961884194817L;

	public TweetAppException(String msg) {
		super(msg);
	}
}
